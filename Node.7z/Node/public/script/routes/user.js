/* document.addEventListener("DOMContentLoaded", function () {
    const registrationForm = document.getElementById("registration-form");
  
    registrationForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const formData = new FormData(registrationForm);
      const formDataObject = {};
      formData.forEach((value, key) => {
          if (key === "age") {
              formDataObject[key] = parseInt(value, 10);
            } else {

                formDataObject[key] = value;
            }
        }
        );

        
        if (formDataObject['cpf'] === '') {
            formDataObject['cpf'] = null;
        }
  
      console.log("Registration Request Data:", formDataObject);
  
      fetch("http://localhost:8080/register", {
        method: "POST",
        body: JSON.stringify(formDataObject),
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((response) => response.json())
        .then((response) => {
          console.log("Registration Response Data:", response);
        })
        .catch((error) => {
          // Handle registration error (e.g., show an error message)
          console.error("Registration error:", error);
        });
    });
  }); */

  function handleRegistrationForm() {
    const registrationForm = document.getElementById("registration-form");

    registrationForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const formData = new FormData(registrationForm);
      const formDataObject = {};

      formData.forEach((value, key) => {
        if (key === "age") {
          formDataObject[key] = parseInt(value, 10);
        } else if (key === "cpf" && value === "") {
          formDataObject[key] = null;
        } else {
          formDataObject[key] = value;
        }
      });

      console.log("Registration Request Data:", formDataObject);

      fetch("http://localhost:8080/register", {
        method: "POST",
        body: JSON.stringify(formDataObject),
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((response) => {
          console.log("Registration Response Data:", response);
        })
        .catch((error) => {
          console.error("Registration error:", error);
        });
    });
  }

  document.addEventListener("DOMContentLoaded", handleRegistrationForm);