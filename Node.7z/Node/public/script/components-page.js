export const input = $("#search-input");
export const loadingIcon = $("#loading");
export const containerError = $("#error");
export const containerList = $("#container-list");